// Theme toggle + typing + nav + reveals + simple blog search + form handler (no backend)
(function(){
  const root = document.documentElement;
  const themeBtn = document.getElementById('themeToggle');
  const navBtn = document.getElementById('navToggle');
  const navMenu = document.getElementById('navMenu');
  const yearEl = document.getElementById('year');
  const typingEl = document.querySelector('.typing');

  // Year
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Theme
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) document.body.setAttribute('data-theme', savedTheme);
  themeBtn?.addEventListener('click', () => {
    const next = document.body.getAttribute('data-theme') === 'light' ? '' : 'light';
    if (next) document.body.setAttribute('data-theme', next);
    else document.body.removeAttribute('data-theme');
    localStorage.setItem('theme', next);
  });

  // Mobile nav
  navBtn?.addEventListener('click', () => {
    const expanded = navBtn.getAttribute('aria-expanded') === 'true';
    navBtn.setAttribute('aria-expanded', String(!expanded));
    navMenu.classList.toggle('open');
  });

  // Smooth scroll & active link
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href').slice(1);
      const target = document.getElementById(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        navMenu.classList.remove('open');
        navBtn?.setAttribute('aria-expanded', 'false');
        history.pushState(null, '', `#${id}`);
      }
    });
  });

  // Typing effect
  const roles = [
    "Aspiring Software Developer",
    "Problem Solver",
    "Tech Enthusiast",
    "UI/UX Curious",
    "Clean Code Advocate"
  ];
  let ti = 0, ci = 0, typing = true;
  function typeLoop(){
    if (!typingEl) return;
    const current = roles[ci];
    ti += typing ? 1 : -1;
    typingEl.textContent = current.slice(0, ti);
    if (typing && ti === current.length) {
      typing = false;
      setTimeout(typeLoop, 1200);
      return;
    }
    if (!typing && ti === 0) {
      typing = true;
      ci = (ci + 1) % roles.length;
    }
    setTimeout(typeLoop, typing ? 70 : 40);
  }
  typeLoop();

  // Reveal on scroll
  const io = new IntersectionObserver((entries) => {
    for (const e of entries) {
      if (e.isIntersecting) {
        e.target.classList.add('revealed');
        io.unobserve(e.target);
      }
    }
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  // Blog search
  const search = document.getElementById('blogSearch');
  const cards = Array.from(document.querySelectorAll('.blog-card'));
  search?.addEventListener('input', () => {
    const q = search.value.toLowerCase();
    cards.forEach(c => {
      const text = c.textContent.toLowerCase() + ' ' + (c.dataset.tags || '');
      c.style.display = text.includes(q) ? '' : 'none';
    });
  });

  // "Read more" demo
  document.querySelectorAll('[data-readmore]').forEach(btn => {
    btn.addEventListener('click', () => {
      alert("This is a placeholder. You can wire this to open a modal or a new page.");
    });
  });

  // Contact form (no backend) -> mailto fallback
  const form = document.getElementById('contactForm');
  const status = document.getElementById('formStatus');
  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const name = data.get('name');
    const email = data.get('email');
    const message = data.get('message');
    const link = `mailto:sattiganga686@gmail.com?subject=Portfolio%20Contact%20from%20${encodeURIComponent(name)}&body=${encodeURIComponent(message + "\n\nFrom: " + email)}`;
    status.textContent = "Opening your email client...";
    setTimeout(() => {
      window.location.href = link;
      status.textContent = "If your email client didn't open, please email me directly.";
    }, 400);
  });
})();